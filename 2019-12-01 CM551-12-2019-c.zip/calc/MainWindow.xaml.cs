﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace calc
{
    //alternative
    //public enum CalcOperator
    //{
    //    PLUS = 1,
    //    MINUS,
    //    DIV,
    //    MUL
    //}

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int calcResult = 0;
        int leftOperand = 0;
        int rightOperand = 0;
        int calcOperator = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void DigitKey_Click(object sender, EventArgs e)
        {
            int digit = -1;
            var btn = sender as Button;
            switch (btn.Name)
            {
                case "zero": digit = 0; break;
                case "one": digit = 1; break;
                case "two": digit = 2; break;
                case "three": digit = 3; break;
                case "four": digit = 4; break;
                case "five": digit = 5; break;
                case "six": digit = 6; break;
                case "seven": digit = 7; break;
                case "eight": digit = 8; break;
                case "nine": digit = 9; break;
            }
            //naive
            if (calcOperator > 0)
            {
                rightOperand = digit;
            }
            else
            {
                leftOperand = digit;
            }
        }

        private void SendResult_Click(object sender, RoutedEventArgs e)
        {
            switch (calcOperator)
            {
                case 1:
                    calcResult = leftOperand + rightOperand;
                    break;
                case 2:
                    calcResult = leftOperand - rightOperand;
                    break;
                case 3:
                    if (leftOperand == 0 || rightOperand == 0)
                        calcResult = 0;
                    else
                        calcResult = leftOperand / rightOperand;
                    break;
                case 4:
                    calcResult = leftOperand * rightOperand;
                    break;
                default:
                    break;
                    
            }
            this.resultLabel.Content = calcResult.ToString();
            leftOperand = rightOperand = calcOperator = -1;
        }

        private void Operator_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;
            switch (btn.Name)
            {
                case "plusBtn": calcOperator = 1; break;
                case "minusBtn": calcOperator = 2; break;                
                case "divBtn": calcOperator = 3; break;
                case "mulBtn": calcOperator = 4; break;
            }
            //alternative
            //switch (btn.Name)
            //{
            //    case "plusBtn": calcOperator = (int)CalcOperator.PLUS; break;
            //    case "minusBtn": calcOperator = (int)CalcOperator.MINUS; break;
            //    case "divBtn": calcOperator = (int)CalcOperator.DIV; break;
            //    case "mulBtn": calcOperator = (int)CalcOperator.MUL; break;
            //}
        }
    }
}
